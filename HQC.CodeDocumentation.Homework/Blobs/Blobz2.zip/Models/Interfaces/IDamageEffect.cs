﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blobs.Models.Interfaces
{
    public interface IDamageEffect
    {
        double DamageEffect { get; }
    }
}
