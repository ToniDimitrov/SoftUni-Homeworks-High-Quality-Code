﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blobs.Models.Interfaces
{
    public interface IAttack : IHealthEffect
    {
        string Name { get; }

        double AttackDamage(IBlob blob);

        double AttackDamageFactor { get; }

        void ApplyEffects(IBlob blob);

    }
}
