﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blobs.Models.Interfaces
{
    public interface IBehavior: IHealthEffect, IDamageEffect
    {
        string Name { get; }

        bool IsTriggered { get; }

        void ApplyEffects(IBlob blob);
    }
}
