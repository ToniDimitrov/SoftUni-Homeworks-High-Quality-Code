﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blobs.Models.Interfaces
{
    public interface IDestroyable
    {
        double Health { get; set; }

        bool IsAlive { get; set; }
    }
}
