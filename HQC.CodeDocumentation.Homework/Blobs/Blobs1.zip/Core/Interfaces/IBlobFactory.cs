﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blobs.Models.Interfaces;

namespace Blobs.Core.Interfaces
{
    interface IBlobFactory
    {
        IBlob CreateBlob(string name, int health, int damage, IBehavior behavior, IAttack attack);
    }
}
