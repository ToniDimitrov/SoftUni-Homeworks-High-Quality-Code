﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blobs.Models.Blob;
using Blobs.Models.Interfaces;

namespace Blobs.Core.Interfaces
{
    interface IBlobsData
    {
        ICollection<IBlob> Blobs { get; set; }

        void AddBlob(IBlob blob);
    }
}
